//++++++++++++++++++++++++++++++++++++++++++++++++++++
//Import the FunctionTool and LlmAgent classes from the @google/adk package
//Import the readFileSync function from the node:fs module
//Import the fileURLToPath function from the node:url module
//Import the dirname and join functions from the node:path module
//Import the z object from the zod package
//++++++++++++++++++++++++++++++++++++++++++++++++++++
import { FunctionTool, LlmAgent } from "@google/adk";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { z } from "zod";
import dotenv from "dotenv";
//++++++++++++++++++++++++++++++++++++++++++++++++++++
dotenv.config();
//++++++++++++++++++++++++++++++++++++++++++++++++++++
//Define the Product interface to represent the structure of a product in the catalogue
//The Product interface includes properties such as id, name, brand, category, description, price, color, size, and stock
//++++++++++++++++++++++++++++++++++++++++++++++++++++
interface Product {
  id: number;
  name: string;
  brand: string;
  category: string;
  description: string;
  price: number;
  color: string;
  size: string;
  stock: number;
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++
//Define the path to the products.json file located in the data directory
//The fileURLToPath function is used to convert the module URL to a file path
//The dirname function is used to get the directory of the current file
//++++++++++++++++++++++++++++++++++++++++++++++++++++
// const currentFilePath = fileURLToPath(import.meta.url);
// const currentDirectory = dirname(currentFilePath);
// const productsFilePath = join(currentDirectory, "data", "products.json");
const productsFilePath = join(
  process.env.PROJECT_ROOT!,
  "data",
  "products.json"
);
//++++++++++++++++++++++++++++++++++++++++++++++++++++
//Define the loadProducts function to read and parse the products.json file
//The function returns an array of Product objects
//If the file cannot be read or parsed, an error is thrown
//++++++++++++++++++++++++++++++++++++++++++++++++++++
function loadProducts(): Product[] {
  try {
    const fileContent = readFileSync(productsFilePath, "utf-8");
    const parsedData: unknown = JSON.parse(fileContent);

    if (!Array.isArray(parsedData)) {
      throw new Error("products.json must contain an array.");
    }

    return parsedData as Product[];
  } catch (error) {
    console.log("Products file path:", productsFilePath);
    console.error("Unable to load products.json:", error);
    throw new Error("The product catalogue could not be loaded.");
  }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++
//Define the containsText function to perform case-insensitive substring matching
//The function takes a value and a searchValue as input and returns true if the value contains the searchValue, ignoring case
//++++++++++++++++++++++++++++++++++++++++++++++++++++
function containsText(value: string, searchValue: string): boolean {
  return value.toLowerCase().includes(searchValue.trim().toLowerCase());
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++
//Define the equalsText function to perform case-insensitive exact matching
//The function takes a value and a searchValue as input and returns true if the value is equal to the searchValue, ignoring case
//++++++++++++++++++++++++++++++++++++++++++++++++++++
function equalsText(value: string, searchValue: string): boolean {
  return value.trim().toLowerCase() === searchValue.trim().toLowerCase();
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++
//Define the searchProducts FunctionTool to search and analyze products from the local products.json catalogue
//The tool accepts various parameters for filtering, sorting, and limiting the results
//The execute function implements the logic for filtering, sorting, and summarizing the products based on the provided parameters
//++++++++++++++++++++++++++++++++++++++++++++++++++++
export const searchProducts = new FunctionTool({
  name: "search_products",
  description: `
Searches and analyses products from the local products.json catalogue.

Use this tool for all product-related questions, including:

- What products are available?
- How many products are available?
- Are there any red products?
- Show products below a certain price.
- Show products above a certain price.
- Find products by name.
- Find products by brand.
- Find products by category.
- Find products by color.
- Find products by size.
- Find products whose description contains specific words.
- Find low-stock products.
- Find out-of-stock products.
- Find the cheapest or most expensive products.
- Calculate total inventory units.
  `.trim(),
  parameters: z.object({
    name: z.string().optional().describe("Partial product name to search for."),

    brand: z
      .string()
      .optional()
      .describe("Product brand, such as Apple, Nike or Sony."),

    category: z
      .string()
      .optional()
      .describe("Product category, such as Clothing, Shoes or Electronics."),

    description: z
      .string()
      .optional()
      .describe("Text that should appear in the product description."),

    color: z
      .string()
      .optional()
      .describe("Product color, such as Red, Black or Blue."),

    size: z
      .string()
      .optional()
      .describe("Product size, such as L, 10, 44mm or One Size."),

    minPrice: z
      .number()
      .nonnegative()
      .optional()
      .describe("Minimum product price, inclusive."),

    maxPrice: z
      .number()
      .nonnegative()
      .optional()
      .describe("Maximum product price, inclusive."),

    minStock: z
      .number()
      .int()
      .nonnegative()
      .optional()
      .describe("Minimum stock quantity, inclusive."),

    maxStock: z
      .number()
      .int()
      .nonnegative()
      .optional()
      .describe("Maximum stock quantity, inclusive."),

    availability: z
      .enum(["available", "out_of_stock", "all"])
      .default("all")
      .describe(
        "Use available for stock greater than zero, out_of_stock for zero stock, or all for every product."
      ),

    sortBy: z
      .enum(["name", "price", "stock"])
      .default("name")
      .describe("Field used to sort the returned products."),

    sortOrder: z
      .enum(["ascending", "descending"])
      .default("ascending")
      .describe("Sort direction."),

    limit: z
      .number()
      .int()
      .min(1)
      .max(50)
      .default(20)
      .describe("Maximum number of products to return."),
  }),
  execute: ({
    name,
    brand,
    category,
    description,
    color,
    size,
    minPrice,
    maxPrice,
    minStock,
    maxStock,
    availability,
    sortBy,
    sortOrder,
    limit,
  }) => {
    try {
      if (
        minPrice !== undefined &&
        maxPrice !== undefined &&
        minPrice > maxPrice
      ) {
        return {
          status: "error",
          message: "Minimum price cannot be greater than maximum price.",
        };
      }

      if (
        minStock !== undefined &&
        maxStock !== undefined &&
        minStock > maxStock
      ) {
        return {
          status: "error",
          message: "Minimum stock cannot be greater than maximum stock.",
        };
      }

      const allProducts = loadProducts();

      let filteredProducts = allProducts.filter((product) => {
        if (name && !containsText(product.name, name)) {
          return false;
        }

        if (brand && !equalsText(product.brand, brand)) {
          return false;
        }

        if (category && !equalsText(product.category, category)) {
          return false;
        }

        if (description && !containsText(product.description, description)) {
          return false;
        }

        if (color && !equalsText(product.color, color)) {
          return false;
        }

        if (size && !equalsText(product.size, size)) {
          return false;
        }

        if (minPrice !== undefined && product.price < minPrice) {
          return false;
        }

        if (maxPrice !== undefined && product.price > maxPrice) {
          return false;
        }

        if (minStock !== undefined && product.stock < minStock) {
          return false;
        }

        if (maxStock !== undefined && product.stock > maxStock) {
          return false;
        }

        if (availability === "available" && product.stock <= 0) {
          return false;
        }

        if (availability === "out_of_stock" && product.stock !== 0) {
          return false;
        }

        return true;
      });

      filteredProducts = filteredProducts.sort(
        (firstProduct, secondProduct) => {
          let comparison = 0;

          if (sortBy === "price") {
            comparison = firstProduct.price - secondProduct.price;
          } else if (sortBy === "stock") {
            comparison = firstProduct.stock - secondProduct.stock;
          } else {
            comparison = firstProduct.name.localeCompare(secondProduct.name);
          }

          return sortOrder === "descending" ? -comparison : comparison;
        }
      );

      const totalMatchingProducts = filteredProducts.length;

      const totalMatchingStockUnits = filteredProducts.reduce(
        (total, product) => total + product.stock,
        0
      );

      const totalMatchingInventoryValue = filteredProducts.reduce(
        (total, product) => total + product.price * product.stock,
        0
      );

      const averagePrice =
        totalMatchingProducts > 0
          ? filteredProducts.reduce(
              (total, product) => total + product.price,
              0
            ) / totalMatchingProducts
          : 0;

      const returnedProducts = filteredProducts.slice(0, limit);

      return {
        status: "success",
        appliedFilters: {
          name,
          brand,
          category,
          description,
          color,
          size,
          minPrice,
          maxPrice,
          minStock,
          maxStock,
          availability,
          sortBy,
          sortOrder,
        },
        summary: {
          totalCatalogueProducts: allProducts.length,
          totalMatchingProducts,
          returnedProductCount: returnedProducts.length,
          totalMatchingStockUnits,
          averageMatchingProductPrice: Number(averagePrice.toFixed(2)),
          totalMatchingInventoryValue: Number(
            totalMatchingInventoryValue.toFixed(2)
          ),
        },

        products: returnedProducts,
      };
    } catch (error) {
      console.error("Product search failed:", error);

      return {
        status: "error",
        message: "Unable to search the product catalogue.",
      };
    }
  },
});
